# Deploy this Solana / Interstellar project on EthioDeploy

This adaptation is based on the uploaded `solana-main.zip`, whose package.json
identifies it as Interstellar 6.3.0. It preserves the existing application,
configuration, assets, dependency versions, lockfile, local vendor archives,
and dependency patch. It does not update the fork from upstream.

## Browser-only update of your existing GitHub repository

Use the small `solana-ethiodeploy-patch.zip` with the same repository that produced
your uploaded ZIP. The complete source archive is also provided as a backup.

1. Unzip the patch on your computer.
2. Open the extracted `solana-ethiodeploy-patch` folder. It contains three files
   plus two folders: `Dockerfile`, `Dockerfile.dockerignore`, `ETHIODEPLOY.md`,
   `scripts`, and `src`.
3. Open the ROOT of your GitHub repository on the branch EthioDeploy deploys
   (previously `main`). Choose **Add file > Upload files**.
4. Drag those five items from INSIDE the extracted folder onto GitHub. Do not
   upload the ZIP itself or the outer `solana-ethiodeploy-patch` folder.
5. Review the paths before committing. The changed files must be:

   ```text
   Dockerfile
   Dockerfile.dockerignore
   ETHIODEPLOY.md
   scripts/check-ethiodeploy.mjs
   src/server.js
   ```

   `src/server.js` should replace the existing file in that folder. Do not delete
   the existing `src` folder or any other files. These are additive/replacement
   updates, not a replacement of the entire repository with the patch folder.
6. Commit to your deployment branch with a message such as
   `Fix EthioDeploy Docker build and startup`.

Do not move `static/assets`, upload `node_modules`, or re-sync the fork during
this deployment attempt. The supplied ZIP already has the correct asset layout.

## EthioDeploy dashboard settings

Open the project's **Settings > Build & Deploy** and use:

| Setting | Value |
| --- | --- |
| Repository | Your repository containing the updated files |
| Branch | `main`, unless you intentionally deploy a different branch |
| Service type | Web Service |
| Root directory | Empty (repository root) |
| Builder | Dockerfile, or Auto (Dockerfile if present) |
| Dockerfile path | `Dockerfile` |
| Install command | Empty; handled by the Dockerfile |
| Build command | Empty; handled by the Dockerfile |
| Start command | Empty; uses the Dockerfile's CMD |
| PORT | Use the platform-provided value, normally `3000` |
| HOST | `0.0.0.0` (already the image default) |

Remove a manual `PORT=80` or `PORT=8080` carried over from a different host.
Do not use a static-site builder for the complete app; it has an HTTP server
and a WebSocket endpoint. No separate database is required for this setup.

A push should trigger deployment. Open the NEW deployment and confirm its
commit matches your new GitHub commit; retrying an old failed deployment may
just retry the old code. If needed, deploy the latest configured branch from
the dashboard rather than selecting an old revision.

## What changed

- Docker uses the Node 22 major release required by this project's engines,
  rather than the unversioned `node:bookworm-slim` image.
- `vendor/` and `patches/` are copied BEFORE dependency installation. The
  original Dockerfile installed from package.json before copying the local
  `file:vendor/...tgz` dependency, so that archive was unavailable at install time.
- Dependencies are installed with pinned pnpm 10.33.0 and the supplied frozen
  lockfile. This retains the pnpm overrides and bare-mux patch rather than
  silently replacing that installation process with npm.
- Only production dependencies are installed. The existing static-mode server
  serves `static/`, including `static/assets/`. Proxy libraries are still
  served from their installed packages. The optional obfuscated `dist/` build
  is intentionally not generated or copied into this image.
- The server explicitly binds `0.0.0.0` and continues to read `PORT`. The Docker
  image defaults to port 3000; the original non-Docker fallback remains 8080.
- A non-sensitive `/healthz` endpoint and a Docker health check are provided.
- The container runs as the non-root `node` user.
- `Dockerfile.dockerignore` excludes local caches, secrets, and stale builds.
  Its visible filename makes browser uploads easier than hidden dotfiles.

## Checks that run automatically in the Docker build

The Dockerfile runs `scripts/check-ethiodeploy.mjs` after installing dependencies.
It checks required files, the local package archives, the dependency patch,
installed proxy bundles, and local HTML asset references. It then starts the
actual server on an isolated test port and checks:

- The health endpoint and seven page routes.
- CSS, JavaScript, and WebAssembly delivery, including content types.
- Service-worker scope headers and protection of the private runtime directory.
- A WebSocket handshake to `/wisp/`.

A successful test prints:

```text
[check] ETHIODEPLOY CHECKS PASSED
```

A failed test stops the build instead of publishing that broken image. This is
an HTTP/asset/handshake check, not an end-to-end test of third-party proxied sites.
It is written for the supplied configuration (Masqr and DNS filtering disabled).
Changing those options may require adapting the deployment check as well.

## Browser-only verification after deployment

Open your normal website address and append `/healthz`. Expect:

```json
{"status":"ok"}
```

Then open `/assets/css/home.css`; it should return CSS text. Open the homepage
and perform a hard refresh if necessary. The health endpoint is deliberately
accessible without the optional app login, but returns only the status above.

## What was and was not verified when this package was prepared

Passed locally: JavaScript syntax of the changed server and added checker,
static HTML asset/layout checks, dependency-manifest/lockfile consistency, and
local vendor archive integrity checks. Negative tests verify that the checker
rejects missing assets and missing vendor archives.

The preparation environment has no Docker engine and cannot resolve the npm
registry, so a full dependency installation, container build, live server test,
and EthioDeploy deployment were NOT executed there. The runtime tests described
above are included for EthioDeploy to execute during its actual Docker build;
their results are not represented as already passed.

No files have been pushed to your GitHub account and no live host settings have
been changed by preparing this archive. Host policy, available resources,
external websites, and end-to-end proxy traffic have not been certified.

## An error this package cannot repair

`git checkout ... fatal: reference is not a tree` happens while EthioDeploy is
checking out a Git commit, before Dockerfile or application code runs. These
changes do not repair the host's checkout process. Confirm the new deployment
uses the current branch/commit; repeated checkout failures require investigation
of the GitHub integration/checkout by the host.

## References checked during preparation

- EthioDeploy builds, Dockerfile selection, and start-command overrides:
  https://ethiodeploy.com/docs/deploys
- EthioDeploy Node.js binding and port requirements:
  https://ethiodeploy.com/deploy/nodejs
- GitHub browser file/folder uploads:
  https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository
- pnpm locked production installation:
  https://pnpm.io/10.x/cli/install
- Dockerfile-specific ignore files:
  https://docs.docker.com/build/concepts/context/#filename-and-location
