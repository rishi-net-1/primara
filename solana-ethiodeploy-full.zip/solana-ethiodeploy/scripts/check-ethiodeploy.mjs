// Deployment checks. No new dependencies are required by this checker.
// --files-only checks the upload without installing packages or starting it.
// The default mode additionally tests the real server during the Docker build.
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { existsSync, readFileSync, readdirSync, statSync } from "node:fs";
import { createRequire } from "node:module";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { setTimeout as delay } from "node:timers/promises";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const STATIC = path.join(ROOT, "static");
const require = createRequire(path.join(ROOT, "package.json"));
const mounts = [
  ["/epoxy/", "@mercuryworkshop/epoxy-transport", "epoxyPath"],
  ["/libcurl/", "@mercuryworkshop/libcurl-transport", "libcurlPath"],
  ["/baremux/", "@mercuryworkshop/bare-mux/node", "baremuxPath"],
  ["/assets/ultraviolet/", "@titaniumnetwork-dev/ultraviolet", "uvPath"],
  ["/assets/scramjet/", "@useinterstellar/scramjet/path", "scramjetPath"],
];
const refs = new Set([
  "/sw.js",
  "/baremux/index.mjs",
  "/baremux/worker.js",
  "/epoxy/index.mjs",
  "/libcurl/index.mjs",
  "/assets/ultraviolet/uv.bundle.js",
  "/assets/ultraviolet/uv.handler.js",
  "/assets/ultraviolet/uv.client.js",
  "/assets/ultraviolet/uv.sw.js",
  "/assets/scramjet/scramjet.all.js",
  "/assets/scramjet/scramjet.sync.js",
  "/assets/scramjet/scramjet.wasm.wasm",
]);
const isFile = file => existsSync(file) && statSync(file).isFile();
const runtimeAsset = pathname => mounts.find(([prefix]) => pathname.startsWith(prefix));

function checkFiles() {
  const manifest = JSON.parse(readFileSync(path.join(ROOT, "package.json"), "utf8"));
  for (const file of [
    "pnpm-lock.yaml", "config.js", "src/server.js", "static/home.html",
    "static/assets/css/global.css", "static/assets/css/home.css",
    "static/assets/css/nav.css", "static/assets/js/storage.js",
    "static/assets/js/main.js", "static/assets/js/search.js", "static/assets/js/home.js",
  ]) assert(isFile(path.join(ROOT, file)), `Missing required file: ${file}`);

  // Verify local dependency tarballs and all patched-dependency files exist.
  for (const value of Object.values(manifest.dependencies)) {
    if (value.startsWith("file:")) {
      assert(isFile(path.join(ROOT, value.slice(5))), `Missing local dependency: ${value}`);
    }
  }
  for (const value of Object.values(manifest.pnpm?.overrides || {})) {
    if (value.startsWith("file:")) {
      assert(isFile(path.join(ROOT, value.slice(5))), `Missing local override: ${value}`);
    }
  }
  for (const patch of Object.values(manifest.pnpm?.patchedDependencies || {})) {
    assert(isFile(path.join(ROOT, patch)), `Missing patch: ${patch}`);
  }

  // Check every local script and stylesheet/icon referenced by an HTML page.
  // Proxy bundles are intentionally installed from packages, not copied by hand.
  const pages = readdirSync(STATIC).filter(file => file.endsWith(".html"));
  for (const page of pages) {
    const html = readFileSync(path.join(STATIC, page), "utf8");
    for (const tag of html.matchAll(/<(script|link)\b[^>]*>/gi)) {
      const attr = tag[1].toLowerCase() === "script" ? "src" : "href";
      const match = tag[0].match(new RegExp(`\\b${attr}\\s*=\\s*["']([^"']+)["']`, "i"));
      if (!match) continue;
      const url = new URL(match[1], `http://deployment-check.invalid/${page}`);
      if (url.origin !== "http://deployment-check.invalid") continue;
      refs.add(url.pathname);
    }
  }
  for (const url of refs) {
    const local = path.join(STATIC, decodeURIComponent(url).replace(/^\/+/, ""));
    assert(isFile(local) || runtimeAsset(url), `Missing static asset: ${url}`);
  }
  console.log(`[check] File layout OK: ${pages.length} HTML pages; ${refs.size} local asset URLs.`);
}

function checkInstalledAssets() {
  const installedMounts = mounts.map(([prefix, name, property]) => {
    const directory = require(name)[property];
    assert(typeof directory === "string", `Missing ${property} export in ${name}`);
    return [prefix, directory];
  });
  for (const url of refs) {
    if (isFile(path.join(STATIC, url.replace(/^\/+/, "")))) continue;
    const mounted = installedMounts.find(([prefix]) => url.startsWith(prefix));
    assert(mounted, `No mounted package serves ${url}`);
    const [prefix, directory] = mounted;
    assert(isFile(path.join(directory, url.slice(prefix.length))), `Installed package is missing ${url}`);
  }
  console.log("[check] Installed proxy bundles and transports OK.");
}

async function checkWebSocket(url) {
  await new Promise((resolve, reject) => {
    const ws = new WebSocket(url);
    const timer = setTimeout(() => {
      reject(new Error("WebSocket handshake timed out"));
      ws.close();
    }, 5000);
    ws.addEventListener("open", () => {
      clearTimeout(timer);
      ws.close();
      resolve();
    }, { once: true });
    ws.addEventListener("error", () => {
      clearTimeout(timer);
      reject(new Error("WebSocket handshake failed"));
    }, { once: true });
  });
}

async function checkServer() {
  // A high, non-privileged port is used only inside the isolated build container.
  // The deployed app still uses the PORT provided by EthioDeploy (normally 3000).
  const port = 39137;
  const origin = `http://127.0.0.1:${port}`;
  let logs = "";
  let spawnError = null;
  const child = spawn(process.execPath, [path.join(ROOT, "src/server.js")], {
    cwd: ROOT,
    env: { ...process.env, PORT: String(port), HOST: "0.0.0.0", NODE_ENV: "production" },
    stdio: ["ignore", "pipe", "pipe"],
  });
  child.on("error", error => { spawnError = error; });
  for (const stream of [child.stdout, child.stderr]) {
    stream.on("data", data => { logs = (logs + data.toString()).slice(-32768); });
  }
  const stopped = new Promise(resolve => child.once("exit", resolve));
  try {
    let ready = false;
    for (let attempt = 0; attempt < 80; attempt++) {
      if (spawnError) throw spawnError;
      if (child.exitCode !== null || child.signalCode !== null) {
        throw new Error(`Server exited before becoming ready:\n${logs}`);
      }
      try {
        const response = await fetch(`${origin}/healthz`, { signal: AbortSignal.timeout(700) });
        ready = response.ok && (await response.json()).status === "ok";
      } catch { /* Startup is still in progress. */ }
      if (ready) break;
      await delay(250);
    }
    assert(ready, `Server did not become ready:\n${logs}`);

    const { default: config } = await import(new URL("../config.js", import.meta.url));
    const headers = {};
    if (config.challenge !== false) {
      const entry = Object.entries(config.users || {})[0];
      assert(entry, "Password protection is enabled but no user is configured");
      headers.Authorization = `Basic ${Buffer.from(`${entry[0]}:${entry[1]}`).toString("base64")}`;
    }
    for (const url of ["/", "/home", "/apps", "/games", "/play.html", "/settings", "/tabs", ...refs]) {
      const response = await fetch(origin + url, { headers, signal: AbortSignal.timeout(5000) });
      assert.equal(response.status, 200, `${url} returned HTTP ${response.status}`);
      const type = response.headers.get("content-type") || "";
      if (url.endsWith(".css")) assert(type.includes("text/css"), `${url} is not CSS`);
      if (/\.m?js$/.test(url)) assert(/javascript/.test(type), `${url} is not JavaScript`);
      if (url.endsWith(".wasm")) assert(type.includes("application/wasm"), `${url} is not WebAssembly`);
      assert((await response.arrayBuffer()).byteLength > 0, `${url} has an empty body`);
    }
    const sw = await fetch(`${origin}/sw.js`, { headers, signal: AbortSignal.timeout(5000) });
    assert.equal(sw.headers.get("service-worker-allowed"), "/", "Missing service-worker scope header");
    await sw.arrayBuffer();
    const hidden = await fetch(`${origin}/.runtime/vendor-map.cjs`, { headers });
    assert.equal(hidden.status, 404, "Internal runtime directory must not be public");
    await hidden.arrayBuffer();
    await checkWebSocket(`ws://127.0.0.1:${port}/wisp/`);
    console.log("[check] HTTP pages, CSS/JS/WASM, service-worker scope and Wisp WebSocket handshake OK.");
    console.log("[check] This checks local delivery, not access to third-party websites.");
  } finally {
    if (child.exitCode === null && child.signalCode === null) {
      child.kill("SIGTERM");
      await Promise.race([stopped, delay(1500)]);
      if (child.exitCode === null && child.signalCode === null) {
        child.kill("SIGKILL");
        await stopped;
      }
    }
  }
}

try {
  checkFiles();
  if (!process.argv.includes("--files-only")) {
    checkInstalledAssets();
    await checkServer();
    console.log("[check] ETHIODEPLOY CHECKS PASSED");
  } else {
    console.log("[check] File-only check passed. Dependency/runtime checks have not run.");
  }
} catch (error) {
  console.error(`[check] FAILED: ${error.message}`);
  process.exitCode = 1;
}
