import { existsSync, readFileSync } from "node:fs";
import http from "node:http";
import { createRequire } from "node:module";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { server as wisp } from "@mercuryworkshop/wisp-js/server";
import chalk from "chalk";
import cookieParser from "cookie-parser";
import express from "express";
import basicAuth from "express-basic-auth";
import config from "../config.js";
// import { mountAnalytics } from "./analytics.js";
import { mountGhGames } from "./games.js";
import { createBlockVerdict, setupFiltering } from "./filtering/index.js";
import { mountMasqr } from "./Masqr.js";
import { injectVersionInfo, resolveVersionInfo } from "./version.js";

console.log(chalk.yellow("🚀 Starting server..."));

const NETLIFY = process.argv.includes("--netlify");

const require = createRequire(import.meta.url);
const __dirname = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

const DIST_DIR = path.join(__dirname, "dist");
const STATIC_DIR = path.join(__dirname, "static");

const VENDOR_MAP_PATH = path.join(DIST_DIR, ".runtime", "vendor-map.cjs");
const vendorMap = existsSync(VENDOR_MAP_PATH) ? require(VENDOR_MAP_PATH) : null;

if (!vendorMap && process.env.VERCEL) {
  throw new Error("dist/.runtime/vendor-map.cjs is missing on Vercel. The build did not run before the function was packaged.");
}

if (NETLIFY && !vendorMap?.netlify) {
  console.log(chalk.red("--netlify needs a Netlify build in dist/. Run `pnpm build:netlify` first."));
  process.exit(1);
}
if (!NETLIFY && vendorMap?.netlify) {
  console.log(chalk.red("dist/ is a Netlify build (no server-side Wisp). Run `pnpm start:netlify` to preview it, or `pnpm build` for the normal server build."));
  process.exit(1);
}

const SERVE_DIR = vendorMap ? DIST_DIR : STATIC_DIR;
console.log(chalk.blue(`Serving from ${path.relative(__dirname, SERVE_DIR)}/`));
if (vendorMap) {
  console.log(chalk.blue(`Build ${vendorMap.build}, proxy scope ${vendorMap.scopes.uv}, scramjet ${vendorMap.scopes.scramjet}`));
} else if (existsSync(DIST_DIR)) {
  console.log(chalk.yellow("dist/ exists but has no .runtime/vendor-map.cjs, run `pnpm build`. Falling back to static/."));
}

const server = http.createServer();
const app = express();

function resolvePort() {
  const args = process.argv.slice(2);
  let flag = null;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    if (arg === "--port" || arg === "-p") flag = args[i + 1];
    else if (arg.startsWith("--port=")) flag = arg.slice("--port=".length);
    else continue;

    if (!/^\d+$/.test(flag ?? "") || Number(flag) < 1 || Number(flag) > 65535) {
      console.log(chalk.red(`Invalid port ${JSON.stringify(flag ?? null)}, expected 1-65535.`));
      process.exit(1);
    }
    break;
  }

  return flag ? Number(flag) : process.env.PORT || 8080;
}

const PORT = resolvePort();
// EthioDeploy forwards HTTP/WebSockets to PORT on the container interface.
const HOST = process.env.HOST || "0.0.0.0";

// A lightweight readiness endpoint, independent of optional login/decoy pages.
// It exposes no configuration, credentials, or environment variables.
app.get("/healthz", (_req, res) => {
  res.set("Cache-Control", "no-store").status(200).json({ status: "ok" });
});

wisp.options.allow_loopback_ips = false;
wisp.options.allow_private_ips = false;

const escapeRegExp = text => text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
const blockedSiteMatchers = config.blockedSites.map(host => new RegExp(`(^|\\.)${escapeRegExp(host.trim().toLowerCase())}$`, "i"));
wisp.options.hostname_blacklist = blockedSiteMatchers.length ? blockedSiteMatchers : null;

const filteringState = await setupFiltering({ wisp, filtering: config.filtering });
const blockVerdict = createBlockVerdict({ blocklist: blockedSiteMatchers, policy: filteringState.policy });

if (NETLIFY) console.log(chalk.yellow("Netlify preview: static files only (plus the /gh-games proxy, which Netlify does with _redirects). No Wisp, password protection or Masqr, as on a static host."));

if (!NETLIFY && config.challenge !== false) {
  console.log(chalk.green("🔒 Password protection is enabled."));
  app.use(basicAuth({ users: config.users, challenge: true }));
}

let masqr = null;
if (!NETLIFY && config.masqr?.enabled) {
  masqr = mountMasqr(app, {
    decoyBase: path.join(STATIC_DIR, "decoy"),
    decoySet: config.masqr.decoy ?? "default",
    searchTrigger: process.env.MASQR_SEARCH_TRIGGER ?? config.masqr.searchTrigger ?? null,
    sites: config.masqr.sites ?? [],
    decoyOnly: config.masqr.decoyOnly === true,
    secureCookie: config.masqr.secureCookie !== false,
    sessionMs: (config.masqr.sessionDays ?? 30) * 24 * 60 * 60 * 1000,
  });
  console.log(chalk.green("🔑 Masqr gate is enabled"));
}

mountGhGames(app);

app.use(cookieParser());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));


const cacheEnabled = config.cache?.enabled === true;
const useAssetCache = cacheEnabled && Boolean(vendorMap?.build);
if (cacheEnabled) {
  console.log(useAssetCache ? chalk.green("📦 Asset caching is enabled (assets cached until the HTML changes)") : chalk.yellow("config.cache.enabled is set but this is not a dist build, so caching is off. Run `pnpm build`."));
}
const REVALIDATE = "no-cache";
const IMMUTABLE = "public, max-age=31536000, immutable";
const buildMarker = useAssetCache ? `.${vendorMap.build}` : null;

function cacheControlFor(filePath) {
  return filePath.includes(buildMarker) ? IMMUTABLE : REVALIDATE;
}

const jsStaticOptions = {
  setHeaders: (res, filePath) => {
    if (useAssetCache && filePath.startsWith(SERVE_DIR)) res.setHeader("Cache-Control", cacheControlFor(filePath));
    const ext = path.extname(filePath);
    if (ext === ".js" || ext === ".mjs") {
      res.type("text/javascript");
      res.setHeader("Service-Worker-Allowed", "/");
    } else if (ext === ".wasm") {
      res.type("application/wasm");
    }
  },
};

app.use("/.runtime", (_req, res) => {
  res.sendStatus(404);
});

if (!NETLIFY) app.post("/filter/verdict", async (req, res) => {
  const host = typeof req.body?.host === "string" ? req.body.host.slice(0, 254) : "";
  res.set("Cache-Control", "no-store").json(await blockVerdict(host));
});

// if (vendorMap?.analytics) mountAnalytics(app, vendorMap.analytics);

if (!vendorMap) {
  try {
    const info = await resolveVersionInfo();
    const settingsHtml = injectVersionInfo(readFileSync(path.join(SERVE_DIR, "settings.html"), "utf8"), info).html;
    const sendSettings = (_req, res) => res.type("html").send(settingsHtml);
    app.get("/settings", sendSettings);
    app.get("/settings.html", sendSettings);
  } catch (err) {
    console.warn(chalk.yellow(`Settings version injection skipped, serving placeholders: ${err.message}`));
  }
}

app.use(express.static(SERVE_DIR, { ...jsStaticOptions, dotfiles: "ignore" }));

if (!vendorMap) {
  const { epoxyPath } = require("@mercuryworkshop/epoxy-transport");
  const { baremuxPath } = require("@mercuryworkshop/bare-mux/node");
  const { libcurlPath } = require("@mercuryworkshop/libcurl-transport");
  const { uvPath } = require("@titaniumnetwork-dev/ultraviolet");
  const { scramjetPath } = require("@useinterstellar/scramjet/path");

  app.use("/epoxy/", express.static(epoxyPath));
  app.use("/libcurl/", express.static(libcurlPath));
  app.use("/baremux/", express.static(baremuxPath));
  app.use("/assets/ultraviolet/", express.static(uvPath, jsStaticOptions));
  app.use("/assets/scramjet/", express.static(scramjetPath, jsStaticOptions));
}

const routes = [
  { path: "/apps", file: "apps.html" },
  { path: "/games", file: "games.html" },
  { path: "/play.html", file: "games.html" },
  { path: "/settings", file: "settings.html" },
  { path: "/tabs", file: "tabs.html" },
  { path: "/home", file: "home.html" },
  { path: "/", file: "home.html" },
];

// In dist the build randomizes the page routes and records them in the vendor map, so serve each
// page at its opaque path (build id vendorMap.routes). "/" and "/play.html" have no entry and stay
// clean. In static/dev vendorMap is null, so the clean routes are used as-is.
routes.forEach(route => {
  const servePath = vendorMap?.routes?.[route.path] || route.path;
  app.get(servePath, (_req, res) => {
    if (useAssetCache) res.setHeader("Cache-Control", REVALIDATE);
    res.sendFile(path.join(SERVE_DIR, route.file));
  });
});

app.use((_req, res) => {
  res.status(404).sendFile(path.join(SERVE_DIR, "404.html"));
});

app.use((err, _req, res, _next) => {
  console.error(err.stack);
  res.status(500).sendFile(path.join(SERVE_DIR, "404.html"));
});

server.on("request", (req, res) => {
  app(req, res);
});

const WISP_PATH = vendorMap?.wisp ?? "/wisp/";

server.on("upgrade", (req, socket, head) => {
  if (NETLIFY) return socket.destroy();
  if (masqr && masqr.isGated(req) && !masqr.isAuthorized(req)) return socket.destroy();
  if (new URL(req.url, "http://localhost").pathname !== WISP_PATH) return socket.destroy();
  wisp.routeRequest(req, socket, head);
});

server.on("listening", () => {
  console.log(chalk.green(`🌍 Server is running on http://${HOST}:${PORT}`));
});

server.on("error", err => {
  console.error(`Server could not listen on ${HOST}:${PORT}: ${err.message}`);
  process.exit(1);
});

server.listen({ port: PORT, host: HOST });
