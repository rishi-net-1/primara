
function shellTop() {
  try {
    return top.document.body?.dataset.shell === "true" ? top : null;
  } catch {
    return null;
  }
}
const cloakHost = shellTop() ?? window;

let inFrame;

try {
  inFrame = window !== top || window.shellRedirecting === true;
} catch (e) {
  inFrame = true;
}
if (store.get("ab") == null) store.set("ab", "true");
if (!inFrame && !navigator.userAgent.includes("Firefox") && store.get("ab") === "true") {
  const popup = open("about:blank", "_blank");
  if (popup && !popup.closed) {
    const doc = popup.document;
    const iframe = doc.createElement("iframe");
    const style = iframe.style;
    const link = doc.createElement("link");
    const script = doc.createElement("script");

    const name = store.get("name") || "My Drive - Google Drive";
    const icon = store.get("icon") || "https://ssl.gstatic.com/docs/doclist/images/drive_2022q3_32dp.png";

    doc.title = (window.laceTitle || (s => s))(name);
    link.rel = "icon";
    link.href = absoluteUrl(icon);

    iframe.src = cloakHost.location.href;
    style.position = "fixed";
    style.top = style.bottom = style.left = style.right = 0;
    style.border = style.outline = "none";
    style.width = style.height = "100%";

    script.textContent = `
      window.onbeforeunload = function (event) {
        const confirmationMessage = 'Leave Site?';
        (event || window.event).returnValue = confirmationMessage;
        return confirmationMessage;
      };
    `;

    doc.head.appendChild(link);
    doc.head.appendChild(script);
    doc.body.appendChild(iframe);

    const pLink = reconstructNavigationUrl(store.get("pLink")) ?? getRandomUrl();
    cloakHost.location.replace(pLink);
  }
}

const SplashT = [
  "Over 8 Million Users since 2023",
  "Fastest growing proxy server",
  "Made by xBubbo",
  "Check out discord.gg/interstellar :)",
  "Thanks for using the site",
  "Follow us on Tiktok (@useinterstellar)",
  "Subscribe to us on YouTube (@unblocking)",
  "Subscribe to my Youtube (@xbubbo)",
  "Check out the settings page",
  "Check out our Patreon (https://www.patreon.com/gointerstellar)",
];

let SplashI = Math.floor(Math.random() * SplashT.length);
const SplashE = document.getElementById("splash");

const laceSplash = window.laceTitle ? s => window.laceTitle(s, false) : s => s;
function paintSplash() {
  SplashE.innerText = laceSplash(SplashT[SplashI]);
}

function cycleSplash() {
  SplashI = (SplashI + 1) % SplashT.length;
  paintSplash();
  SplashE.style.animation = "none";
  void SplashE.offsetWidth;
  SplashE.style.animation = "";
}

paintSplash();
SplashE.addEventListener("click", cycleSplash);

function getRandomUrl() {
  const randomUrls = [
    "https://kahoot.it",
    "https://classroom.google.com",
    "https://drive.google.com",
    "https://google.com",
    "https://docs.google.com",
    "https://slides.google.com",
    "https://www.nasa.gov",
    "https://blooket.com",
    "https://clever.com",
    "https://edpuzzle.com",
    "https://khanacademy.org",
    "https://wikipedia.org",
    "https://dictionary.com",
  ];
  return randomUrls[randRange(0, randomUrls.length)];
}

function randRange(min, max) {
  return Math.floor(Math.random() * (max - min) + min);
}

function openHomeAboutBlank() {
  if (navigator.userAgent.includes("Firefox")) {
    return;
  }

  const popup = open("about:blank", "_blank");
  if (!popup || popup.closed) {
    alert("Window blocked. Please allow popups for this site.");
    return;
  }

  const doc = popup.document;
  const iframe = doc.createElement("iframe");
  const link = doc.createElement("link");
  const script = doc.createElement("script");
  doc.title = (window.laceTitle || (s => s))(store.get("name") || "My Drive - Google Drive");
  link.rel = "icon";
  link.href = absoluteUrl(store.get("icon") || "https://ssl.gstatic.com/docs/doclist/images/drive_2022q3_32dp.png");
  iframe.src = cloakHost.location.href;
  Object.assign(iframe.style, { position: "fixed", inset: "0", border: "none", outline: "none", width: "100%", height: "100%" });
  script.textContent = "window.onbeforeunload = event => { const message = 'Leave Site?'; (event || window.event).returnValue = message; return message; };";
  doc.head.append(link, script);
  doc.body.appendChild(iframe);

  const panicLink = reconstructNavigationUrl(store.get("pLink")) ?? getRandomUrl();
  cloakHost.location.replace(panicLink);
}

document.getElementById("about-blank-button").addEventListener("click", openHomeAboutBlank);

(function buildHeading() {
  const heading = document.querySelector("h1.title");
  if (!heading) return;
  const codes = [73, 110, 116, 101, 114, 115, 116, 101, 108, 108, 97, 114];
  const twins = { 116: "т", 101: "е", 115: "ѕ", 97: "а", 73: "І" };
  let text = "";
  for (const code of codes) text += twins[code] && Math.random() < 0.4 ? twins[code] : String.fromCharCode(code);
  heading.textContent = text;
})();
